# Mayon Escape
Student tourism website project about Mayon Volcano and Albay.

## Images
The gallery uses real Mayon/Albay photographs with source and license information displayed under each image. Verify the current license/attribution requirements before final submission.

## Safety
The website references DOST-PHIVOLCS for volcano status. It is not a substitute for official advisories.

## Publish
Upload `index.html` to your GitHub Pages repository. Keep the file as `index.html` in the published root.
